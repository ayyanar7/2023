package com.ag.bta.main.models;

public class Proprietor {
private String strName= null;
private String strGender= null;
private String strShopAddress1= null;
private String strShopAddress2= null;
private String strShopAddress3= null;
private String strShopPincode= null;
private String strShopState= null;
private String strShopCountry= null;
private String strShopContactNo= null;
private String strPersonalContactNO= null;
private String strEmailId= null;
public String getStrName() {
	return strName;
}
public void setStrName(String strName) {
	this.strName = strName;
}
public String getStrGender() {
	return strGender;
}
public void setStrGender(String strGender) {
	this.strGender = strGender;
}
public String getStrShopAddress1() {
	return strShopAddress1;
}
public void setStrShopAddress1(String strShopAddress1) {
	this.strShopAddress1 = strShopAddress1;
}
public String getStrShopAddress2() {
	return strShopAddress2;
}
public void setStrShopAddress2(String strShopAddress2) {
	this.strShopAddress2 = strShopAddress2;
}
public String getStrShopAddress3() {
	return strShopAddress3;
}
public void setStrShopAddress3(String strShopAddress3) {
	this.strShopAddress3 = strShopAddress3;
}
public String getStrShopPincode() {
	return strShopPincode;
}
public void setStrShopPincode(String strShopPincode) {
	this.strShopPincode = strShopPincode;
}
public String getStrShopState() {
	return strShopState;
}
public void setStrShopState(String strShopState) {
	this.strShopState = strShopState;
}
public String getStrShopCountry() {
	return strShopCountry;
}
public void setStrShopCountry(String strShopCountry) {
	this.strShopCountry = strShopCountry;
}
public String getStrShopContactNo() {
	return strShopContactNo;
}
public void setStrShopContactNo(String strShopContactNo) {
	this.strShopContactNo = strShopContactNo;
}
public String getStrPersonalContactNO() {
	return strPersonalContactNO;
}
public void setStrPersonalContactNO(String strPersonalContactNO) {
	this.strPersonalContactNO = strPersonalContactNO;
}
public String getStrEmailId() {
	return strEmailId;
}
public void setStrEmailId(String strEmailId) {
	this.strEmailId = strEmailId;
}






}
