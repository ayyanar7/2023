package com.ag.bta.constants.database;

public class TableName {
    public static final String ACCOUNT = "ACCOUNT";
    public static final String DESIGN = "DESIGN";
    public static final String PHOTO_TABLE = "PROFILE";
}
