package com.ag.bta.ui.treeview.treeviewlib;


public interface LayoutItemType {
    int getLayoutId();
}
