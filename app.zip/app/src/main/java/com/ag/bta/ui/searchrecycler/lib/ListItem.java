package com.ag.bta.ui.searchrecycler.lib;

public abstract class ListItem {
    public abstract int getType();
}
