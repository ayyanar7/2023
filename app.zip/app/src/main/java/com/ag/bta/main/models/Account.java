package com.ag.bta.main.models;

public class Account {
    private String name = null;
    private String email = null;
    private String mobileno = null;
    private String pwd = null;
    private String type = null; // 1- admin & 2 - user
}
