package com.ag.bta.constants.database;

public class ColumnName {
    public static final String KEY = "KEY_PRIMARY";
    public static final String ID = "ID";
    public static final String YEAR = "YEAR";
    public static final String MONTH = "MONTH";
    public static final String SALT = "SALT";
    public static final String IV = "IV";
    public static final String ENCRYPT ="ENCRYPT";
    public static final String DATE = "DATE";
    public static final String JSON_OBJECT = "JSONOBJ";
    public static final String PHOTO = "PHOTO";
    public static final String TABS = "TABS";



}
