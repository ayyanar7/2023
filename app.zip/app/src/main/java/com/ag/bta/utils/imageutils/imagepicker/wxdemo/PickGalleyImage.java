package com.ag.bta.utils.imageutils.imagepicker.wxdemo;

public class PickGalleyImage {
}
