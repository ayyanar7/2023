package com.ag.bta.constants;

public class EncryptConstant {

    public static final String SALT = "SALT";
    public static final String IV = "IV";
    public static final String ENCRYPT ="ENCRYPT";

    public static final byte[] SALT_VALUE = {1,2,3,4,-1,3};
    public static final byte[] IV_VALUE = {3,2,1,0};
}
