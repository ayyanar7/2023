package com.ag.bta.constants;

public class GSTRate {
    public static final double IGST_RATE = 28.00;
    public static final double CGST_RATE = 14.00;
    public static final double SGST_RATE = 14.00;
    public static final String HSN_CODE = "8507";
}
