package com.ag.bta.test.jsongenerator;

public class Products {
    private String id = null;
    private String name = null;
    private String description = null;
    //private String name = null;
}
